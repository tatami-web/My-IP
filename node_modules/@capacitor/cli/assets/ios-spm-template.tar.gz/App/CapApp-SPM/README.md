# CapApp-SPM

> [!WARNING]
> SPM Support is currently experimental.

This SPM is used to host SPM dependancies for you Capacitor project

Do not modifiy the contents of it or there may be unintended concquences.
